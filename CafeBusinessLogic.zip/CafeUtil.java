//import uti.ArrayList
import java.util.ArrayList;

public class CafeUtil {
    
    //"A reward system for customers who by more drinks than they week before"
    //1) create method getStreakGoal(), define type as int
    public int getStreakGoal() {
        int sum = 0; //define type, name sum, start at 0
        for(int week = 1; week < 11; week++){//for loop through 10 weeks as an int,
            sum += week; //continue adding sum to each week's total
        }
        return sum;
    }

    //Given an array of item prices from an order,
    //sum all the prices in the array and return the total
    public double getOrderTotal(double[] lineItems) {
        double total = 0;
        for(double price: lineItems) { //for price in each lineItem
            total += price; //add each price to total
        }
        return total;
    }
    //given an ArrayList of strings named menuItems, print each index, and item
    public void displayMenu(ArrayList<String> menuItems) {
        for (int item = 0; item <menuItems.size(); item++) { //for each item in the given menuItems
            //String name = myArray.get(0);
            System.out.printf("%s %s \n", item, menuItems.get(item)); //f-statment, with placeholders and key:value pairs
///n used for line breaks
        }

    }
    //create method addCustomer into an ArrayList of Strings named "customers"
    public void addCustomer(ArrayList<String> customers) {
        System.out.println("Please enter your name:");
        String userName = System.console().readLine(); //processes user input and labels is at userName
        System.out.printf("Hello, %s! ", userName); //print userName
        System.out.printf("There are %s people in front of you.\n", customers.size()); //count how many people in front of user (use size of array)
        customers.add(userName); //add userName to list of customers using .add
        System.out.println(customers); //print customer list
    }
    //
    public void printPriceChart(String product, double price, int maxQuantity)
        
}

